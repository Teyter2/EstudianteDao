module com.benjamin.cartes.gestorestudiantesjson {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens com.benjamin.cartes.gestorestudiantesjson to javafx.fxml;
    exports com.benjamin.cartes.gestorestudiantesjson;
    exports com.benjamin.cartes.gestorestudiantesjson.controller;
    opens com.benjamin.cartes.gestorestudiantesjson.controller to javafx.fxml;
}
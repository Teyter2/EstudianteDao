package com.benjamin.cartes.gestorestudiantesjson.controller;

import com.benjamin.cartes.gestorestudiantesjson.dto.EstudianteDto;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class EstudianteController {

    private final ObservableList<EstudianteDto> estudiantes =
            FXCollections.observableArrayList();

    @FXML private TableView<EstudianteDto> tablaEstudiantes;
    @FXML private TableColumn<EstudianteDto, Integer> colId;
    @FXML private TableColumn<EstudianteDto, String> colNombre;
    @FXML private TableColumn<EstudianteDto, String> colCorreo;
    @FXML private TableColumn<EstudianteDto, Integer> colEdad;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        // TU TURNO: configura colCorreo y colEdad igual que las dos de arriba
        tablaEstudiantes.setItems(estudiantes);
    }

    @FXML
    private void agregarEjemplo() {
        // TU TURNO: crea un EstudianteDto de ejemplo y agrégalo a la lista
    }

    @FXML
    private void cargarJson() {
        // Más adelante: pedirá los datos al Service
    }

    @FXML
    private void guardarJson() {
        // Más adelante: enviará los datos al Service
    }
}
package com.benjamin.cartes.gestorestudiantesjson;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(EstudianteApplication.class, args);
    }
}

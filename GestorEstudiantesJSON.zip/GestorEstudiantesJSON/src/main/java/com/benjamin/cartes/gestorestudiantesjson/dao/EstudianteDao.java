package com.benjamin.cartes.gestorestudiantesjson.dao;

public class EstudianteDao {
}
